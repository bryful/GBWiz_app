package jp.gbwiz;
import android.test.ActivityInstrumentationTestCase2;
import android.content.Intent;
import android.view.KeyEvent;
import java.io.*;
import java.lang.reflect.Field;
import java.util.Arrays;

public final class CharacterFlowTest extends ActivityInstrumentationTestCase2<MainActivity>{
    public CharacterFlowTest(){super(MainActivity.class);}
    private MainActivity activity;private GameView view;private long handle;
    private void field(String name,Object value)throws Exception{Field field=MainActivity.class.getDeclaredField(name);field.setAccessible(true);field.set(activity,value);}
    private byte[] fixture(String name)throws Exception{
        try(InputStream in=new FileInputStream(new File(getInstrumentation().getTargetContext().getCacheDir(),name));ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buffer=new byte[16384];int count;while((count=in.read(buffer))!=-1)out.write(buffer,0,count);return out.toByteArray();
        }
    }
    private void prepare(String checkpoint)throws Exception{
        setActivityIntent(new Intent().putExtra("test_ui",true));activity=getActivity();
        byte[] rom=fixture("test.gb"),state=fixture(checkpoint);final Exception[] failure={null};
        getInstrumentation().runOnMainSync(()->{try{
            // Isolate this UI test from the user's document tree and frame loop.
            field("resumed",false);field("store",null);
            handle=NativeCore.open(rom,null);assertTrue(NativeCore.loadState(handle,state));field("core",handle);
            Field member=MainActivity.class.getDeclaredField("view");member.setAccessible(true);view=(GameView)member.get(activity);
            // Native test sessions default to OFF; isolate the activity's
            // desired settings from any settings loaded from the user's tree.
            field("noMpCost",false);field("mixedParty",false);
            view.noMpCost=view.mixedParty=false;
            view.mpSupported=NativeCore.mpSupported(handle);view.partySupported=NativeCore.partySupported(handle);
        }catch(Exception e){failure[0]=e;}});
        if(failure[0]!=null)throw failure[0];
    }
    private void key(int code){getInstrumentation().runOnMainSync(()->{activity.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN,code));activity.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_UP,code));});getInstrumentation().waitForIdleSync();}
    private void picker(){key(KeyEvent.KEYCODE_F1);key(KeyEvent.KEYCODE_DPAD_UP);key(KeyEvent.KEYCODE_X);key(KeyEvent.KEYCODE_DPAD_UP);key(KeyEvent.KEYCODE_DPAD_UP);key(KeyEvent.KEYCODE_DPAD_UP);key(KeyEvent.KEYCODE_X);}
    public void testSelectBeforeExecute()throws Exception{
        prepare("gaiden1-camp.bin");byte[] before=NativeCore.battery(handle);picker();assertNotNull(view.spellCharacters);
        key(KeyEvent.KEYCODE_DPAD_DOWN);key(KeyEvent.KEYCODE_DPAD_DOWN);key(KeyEvent.KEYCODE_DPAD_DOWN);key(KeyEvent.KEYCODE_X);
        assertNull(view.spellCharacters);assertTrue(view.characterMenu);assertTrue(view.characterName.contains("そうりょ1"));
        assertTrue("Selecting a character already applied the action",Arrays.equals(before,NativeCore.battery(handle)));
        key(KeyEvent.KEYCODE_X);byte[] after=NativeCore.battery(handle);int at=0x17+2*128+0x39;
        assertEquals(31,after[at]&31);for(int i=1;i<8;i++)assertEquals(255,after[at+i]&255);
        for(int alignment=0;alignment<3;alignment++){
            key(KeyEvent.KEYCODE_DPAD_DOWN);assertEquals(2+alignment,view.menuRow);
            byte[] unchanged=NativeCore.battery(handle);key(KeyEvent.KEYCODE_DPAD_RIGHT);
            assertTrue("Left/right applied alignment",Arrays.equals(unchanged,NativeCore.battery(handle)));
            key(KeyEvent.KEYCODE_X);byte[] changed=NativeCore.battery(handle);
            assertEquals(alignment,changed[0x17+2*128+10]&255);
            for(int slot=0;slot<6;slot++)for(int i=0;i<128;i++)if(slot!=2||i!=10)assertEquals(unchanged[0x17+slot*128+i],changed[0x17+slot*128+i]);
        }
        assertTrue(view.characterMenu);key(KeyEvent.KEYCODE_Z);assertNotNull(view.spellCharacters);assertFalse(view.characterMenu);
        key(KeyEvent.KEYCODE_Z);assertNull(view.spellCharacters);assertTrue(view.supportMenu);
    }
    public void testGlobalMpSetting()throws Exception{
        prepare("gaiden1-town.bin");assertTrue(NativeCore.mpSupported(handle));assertFalse(NativeCore.noMpCost(handle));
        key(KeyEvent.KEYCODE_F1);key(KeyEvent.KEYCODE_DPAD_UP);key(KeyEvent.KEYCODE_X);key(KeyEvent.KEYCODE_DPAD_UP);
        key(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.supportMenu);assertEquals(5,view.menuRow);key(KeyEvent.KEYCODE_X);assertFalse(NativeCore.noMpCost(handle));
        key(KeyEvent.KEYCODE_DPAD_RIGHT);assertTrue(NativeCore.noMpCost(handle));assertTrue(view.noMpCost);
        key(KeyEvent.KEYCODE_DPAD_LEFT);assertFalse(NativeCore.noMpCost(handle));assertFalse(view.noMpCost);
    }
    public void testMixedPartySetting()throws Exception{
        prepare("gaiden1-town.bin");assertTrue(NativeCore.partySupported(handle));assertFalse(NativeCore.mixedParty(handle));
        key(KeyEvent.KEYCODE_F1);key(KeyEvent.KEYCODE_DPAD_UP);key(KeyEvent.KEYCODE_X);key(KeyEvent.KEYCODE_DPAD_UP);
        assertTrue(view.supportMenu);assertEquals(6,view.menuRow);key(KeyEvent.KEYCODE_X);assertFalse(NativeCore.mixedParty(handle));
        byte[] before=NativeCore.state(handle);key(KeyEvent.KEYCODE_DPAD_RIGHT);assertTrue(NativeCore.mixedParty(handle));assertTrue(view.mixedParty);assertTrue(Arrays.equals(before,NativeCore.state(handle)));
        key(KeyEvent.KEYCODE_DPAD_LEFT);assertFalse(NativeCore.mixedParty(handle));assertFalse(view.mixedParty);
    }
    public void testBattleExclusion()throws Exception{
        prepare("gaiden1-before-win.bin");byte[] before=NativeCore.state(handle);picker();
        assertNull("Battle picker opened",view.spellCharacters);assertFalse("Battle character menu opened",view.characterMenu);assertTrue("Rejected battle picker changed state",Arrays.equals(before,NativeCore.state(handle)));
    }
}
