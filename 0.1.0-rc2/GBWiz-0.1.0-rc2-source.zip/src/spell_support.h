#pragma once
#include "game_support.h"

struct SpellCharacter {unsigned slot;std::string name;};
class SpellSupport {
    bool supported_=false;
    bool alignmentSupported_=false;
    int workingSlot_=-1;
    bool resyncNeeded_=false;
    std::array<unsigned char,9> workingIdentity_{};
    static constexpr size_t roster=0x1186,saveRoster=0x17,mirror=0xe4a,recordSize=128;
    static unsigned checksum(const unsigned char* record){
        unsigned result=0;for(unsigned i=0;i<127;i++)result+=record[i]|(unsigned(record[i+1])<<8);return result&65535;
    }
    static std::string name(const unsigned char* bytes){
        std::u32string text;
        for(unsigned i=0;i<8&&bytes[i];i++){
            unsigned c=bytes[i];char32_t glyph=U'?';
            if(c>=0x20&&c<=0x7e)glyph=c;
            else if(c>=0x91&&c<=0x9f)glyph=U"あいうえおかきくけこさしすせそ"[c-0x91];
            else if(c>=0xe0&&c<=0xee)glyph=U"たちつてとなにぬねのはひふへほ"[c-0xe0];
            else if(c>=0xef&&c<=0xf6)glyph=U"まみむめもやゆよ"[c-0xef];
            else if(c>=0xf7&&c<=0xfd)glyph=U"らりるれろわん"[c-0xf7];
            else if(c>=0xb1&&c<=0xbf)glyph=U"アイウエオカキクケコサシスセソ"[c-0xb1];
            else if(c>=0xc0&&c<=0xce)glyph=U"タチツテトナニヌネノハヒフヘホ"[c-0xc0];
            else if(c>=0xcf&&c<=0xd6)glyph=U"マミムメモヤユヨ"[c-0xcf];
            else if(c>=0xd7&&c<=0xdd)glyph=U"ラリルレロワン"[c-0xd7];
            else if(c>=0x86&&c<=0x8f)glyph=U"をぁぃぅぇぉゃゅょっ"[c-0x86];
            else if(c>=0xa5&&c<=0xaf)glyph=U"ーヲァィゥェォャュョッ"[c-0xa5];
            else if(c==0xde)glyph=0x3099;else if(c==0xdf)glyph=0x309a;
            text.push_back(glyph);
        }
        std::string result;
        for(char32_t c:text){if(c<128)result.push_back(char(c));else if(c<2048){result.push_back(char(0xc0|(c>>6)));result.push_back(char(0x80|(c&63)));}else{result.push_back(char(0xe0|(c>>12)));result.push_back(char(0x80|((c>>6)&63)));result.push_back(char(0x80|(c&63)));}}
        return result;
    }
public:
    static bool recognizes(const std::vector<char>& rom){
        if(identifyGame(rom).id!=GameId::Gaiden1||rom.size()<0x10000)return false;
        const unsigned char counts[]={4,4,4,4,5,4,4,5,4,5,5,5,4,4};
        const unsigned char fields[]={0x21,0x3d,0xd1,0xcd,0xfb,2,0x21,0xc0,0xd0,0xcd,8,3,0x11,0x45,0xd1,1,0x44,0x26};
        const unsigned char sum[]={0x21,0,0,0x1b,0xd5,0x0a,0x5f,3,0x0a,0x57,0x19,0xd1,0x1b,0x7a,0xb3,0x20,0xf3};
        const unsigned char copy[]={0x21,0x17,0xa0,0x11,0x61,0xae,1,0x4a,0x0e,0xcd,0x85,0x21};
        const unsigned char loadWork[]={0xcd,0x35,0x1b,0x11,4,0xd1,1,0x80,0,0xcd,0x85,0x21,0xc9};
        const unsigned char saveWork[]={0xf5,0xcd,0x35,0x1b,0x54,0x5d,0x21,4,0xd1,1,0x80,0,0xcd,0x85,0x21};
        const unsigned char consume[]={0xf5,0xcd,0x18,0x13,0xfa,0xfa,0xd0,0xcd,0xc4,0x10,0x35,0xf1,0xc3,0x46,0x13};
        const unsigned char battleMode[]={0x3e,0x14,0xea,0x88,0xc5};
        auto matches=[&](size_t at,const auto& bytes){return std::equal(std::begin(bytes),std::end(bytes),reinterpret_cast<const unsigned char*>(rom.data()+at));};
        return rom.size()>=0x10088&&matches(0x2644,counts)&&matches(0xb11a,fields)&&matches(0xd05,sum)&&matches(0xce7,copy)&&matches(0x1318,loadWork)&&matches(0x1346,saveWork)&&matches(0x10083,battleMode)&&matches(0xee7a,consume);
    }
    static bool recognizesAlignment(const std::vector<char>& rom){
        if(!recognizes(rom)||rom.size()<0x16de5)return false;
        // Creation stores the selected good/neutral/evil index in D10E;
        // the original display indexes the same three labels with that byte.
        const unsigned char creation[]={0x3e,3,0xcd,4,0x1c,0xcd,0x39,0x1d,0xea,0x0e,0xd1,0xcd,0x4b,0x1b};
        const unsigned char display[]={0x6f,0x26,0,0x29,0x11,0x61,0x1b,0x19,0x4e,0x23,0x46,0xc9};
        const unsigned char labels[]={0x9e,0xde,0xfd,0x20,0x20,0,0xe1,0x8d,0x93,0xf8,0xe2,0,0x91,0x98,0x20,0x20,0x20,0};
        const unsigned char pointers[]={0x7e,0x40,0x84,0x40,0x8a,0x40};
        const unsigned char party[]={0xfa,0x4f,0xc9,0xb7,0xc8,0xaf,0x21,0x50,0xc9,0xf5,0xe5,0xcd,0xb0,0x0e,0xfa,0x0e,0xd1,0x5f,0xcb,0x0b,0xcb,0x0b,0xe1,0x7e,0xe6,0x3f,0xb3,0x22};
        auto matches=[&](size_t at,const auto& bytes){return std::equal(std::begin(bytes),std::end(bytes),reinterpret_cast<const unsigned char*>(rom.data()+at));};
        return matches(0x16dd7,creation)&&matches(0x1b4b,display)&&matches(0x407e,labels)&&matches(0x1b61,pointers)&&matches(0x64d,party);
    }
    void attach(const std::vector<char>& rom){supported_=recognizes(rom);alignmentSupported_=recognizesAlignment(rom);workingSlot_=-1;resyncNeeded_=false;}
    bool supported()const{return supported_;}
    bool alignmentSupported()const{return alignmentSupported_;}
    bool battle(gambatte::GB& core)const{return supported_&&static_cast<const unsigned char*>(core.rambank0_ptr())[0x588]==0x14;}
    bool busy(gambatte::GB& core)const{
        auto regs=core.cpuRegisters();auto copy=[](unsigned pc){return pc>=0x2185&&pc<=0x218d;};
        if(copy(regs.pc))return true;
        auto ram=static_cast<const unsigned char*>(core.rambank0_ptr());
        // A VBlank/timer interrupt can suspend the shared copy routine.
        if(regs.sp>=0xc000&&regs.sp<0xe000)for(unsigned at=regs.sp;at+1<0xe000;at+=2)if(copy(ram[at-0xc000]|(unsigned(ram[at-0xc000+1])<<8)))return true;
        return false;
    }
    bool available(gambatte::GB& core)const{
        if(!supported_||core.isCgb()||core.savedata_size()!=8192||battle(core)||busy(core))return false;
        auto ram=static_cast<const unsigned char*>(core.rambank0_ptr());
        for(unsigned slot=0;slot<20;slot++){auto record=ram+roster+slot*recordSize;if(record[0]&&std::memcmp(record+120,"Wizardry",8)==0)return true;}
        return false;
    }
    void resync(gambatte::GB& core){
        workingSlot_=-1;resyncNeeded_=false;if(!supported_)return;
        auto ram=static_cast<const unsigned char*>(core.rambank0_ptr());auto work=ram+0x1104;
        if(!work[0]||std::memcmp(work+120,"Wizardry",8))return;
        std::copy(work,work+9,workingIdentity_.begin());
        int candidate=-1;
        for(unsigned slot=0;slot<20;slot++){auto record=ram+roster+slot*recordSize;
            if(record[0]&&std::memcmp(record,work,9)==0){if(candidate!=-1){workingSlot_=-2;return;}candidate=static_cast<int>(slot);}}
        if(candidate>=0)workingSlot_=std::memcmp(work,ram+roster+candidate*recordSize,recordSize)==0?candidate:-2;
    }
    void observe(gambatte::GB& core,unsigned pc,unsigned address,unsigned value){
        if(!supported_)return;
        auto ram=static_cast<const unsigned char*>(core.rambank0_ptr());
        if(pc==0x2187&&address==0xd104){
            unsigned source=core.cpuRegisters().hl-1;
            if(source>=0xd186&&source<0xdb86&&(source-0xd186)%128==0){workingSlot_=static_cast<int>((source-0xd186)/128);std::copy(ram+source-0xc000,ram+source-0xc000+9,workingIdentity_.begin());resyncNeeded_=false;}
            else workingSlot_=-1; // New character or another unregistered workspace.
        }else if(address>=0xd104&&address<=0xd10c&&pc!=0x2187&&ram[address-0xc000]!=value)workingSlot_=-1;
        if(pc==0x2187&&address>=0xd186&&address<0xdb86&&(address-0xd186)%128==0){
            unsigned source=core.cpuRegisters().hl-1;
            if(source==0xd104){workingSlot_=static_cast<int>((address-0xd186)/128);std::copy(ram+0x1104,ram+0x110d,workingIdentity_.begin());resyncNeeded_=false;}
            else resyncNeeded_=true; // Roster reorder/load: resolve again once paused.
        }
    }
    bool town(gambatte::GB& core)const{
        if(!supported_||core.isCgb()||core.savedata_size()!=8192)return false;
        auto io=static_cast<const unsigned char*>(core.zeropage_ptr())-0x80;
        if(!(io[0x40]&0x80)||io[0x42]||io[0x43])return false;
        auto map=static_cast<const unsigned char*>(core.vram_ptr())+((io[0x40]&8)?0x1c00:0x1800);
        const unsigned char top[]={0x10,0x11,0x10,0x10,0x10,0x10,0x12,0x13,0x14,0x15,0x16};
        const unsigned char lower[]={0x10,0x5b,0x5c,0x5d,0x5d,0x5d,0x5d,0x5e,0x5f,0x60,0x5d};
        return std::equal(std::begin(top),std::end(top),map)&&std::equal(std::begin(lower),std::end(lower),map+8*32);
    }
    std::vector<SpellCharacter> characters(gambatte::GB& core)const{
        std::vector<SpellCharacter> result;if(!available(core))return result;
        auto ram=static_cast<const unsigned char*>(core.rambank0_ptr());
        for(unsigned slot=0;slot<20;slot++){auto record=ram+roster+slot*recordSize;if(record[0]&&std::memcmp(record+120,"Wizardry",8)==0)result.push_back({slot,name(record)});}
        return result;
    }
private:
    template<class Apply> bool edit(gambatte::GB& core,unsigned slot,Apply apply){
        if(!available(core)||slot>=20)return false;
        if(resyncNeeded_)resync(core);
        auto record=static_cast<unsigned char*>(core.rambank0_ptr())+roster+slot*recordSize;
        auto save=static_cast<unsigned char*>(core.savedata_ptr());auto primary=save+saveRoster+slot*recordSize;
        if(!record[0]||std::memcmp(record+120,"Wizardry",8))return false;
        auto work=static_cast<unsigned char*>(core.rambank0_ptr())+0x1104;
        if(workingSlot_>=0&&std::memcmp(work,workingIdentity_.data(),9))resync(core);
        if(workingSlot_==-2&&std::memcmp(record,workingIdentity_.data(),9)==0)return false;
        if(!primary[0]||std::memcmp(primary,record,9)||std::memcmp(primary+120,"Wizardry",8))return false;
        apply(record);
        if(workingSlot_==static_cast<int>(slot))apply(work);
        // Merge only the selected fields; preserve other live/saved stats.
        apply(primary);
        std::copy(primary,primary+recordSize,primary+mirror);
        unsigned sum=checksum(primary);
        for(size_t base:{size_t(0xe07),size_t(0x1c51)}){save[base+slot*2]=sum&255;save[base+slot*2+1]=sum>>8;}
        return true;
    }
public:
    bool learn(gambatte::GB& core,unsigned slot){return edit(core,slot,[](unsigned char* data){data[0x39]|=0x1f;std::fill(data+0x3a,data+0x41,0xff);});}
    bool restoreMp(gambatte::GB& core,unsigned slot){return edit(core,slot,[](unsigned char* data){std::fill(data+0x41,data+0x4f,9);});}
    bool setAlignment(gambatte::GB& core,unsigned slot,unsigned alignment){
        if(!alignmentSupported_||alignment>2)return false;
        if(!edit(core,slot,[alignment](unsigned char* data){data[0x0a]=static_cast<unsigned char>(alignment);}))return false;
        // Party entries also cache alignment in bits 6-7 (ROM 064D).
        // Preserve the member index and status bit, including unused entries.
        auto ram=static_cast<unsigned char*>(core.rambank0_ptr());
        for(unsigned i=0;i<std::min(unsigned(ram[0x94f]),6u);i++){
            auto& member=ram[0x950+i];if(member!=0xff&&(member&31)==slot)member=static_cast<unsigned char>((member&63)|(alignment<<6));
        }
        return true;
    }
};
