#pragma once
#include "game_support.h"

// A single global setting; suppress only validated spell MP decrements.
class MpSupport {
    struct Profile {
        GameId id;unsigned firstMp,bankAddress,level,field,menu,load,save,scratch,menuFlag,random,battleScratch,counts;
    };
    const Profile* profile_=nullptr;
    bool supported_=false,enabled_=false;
    static const Profile* profile(const std::vector<char>& rom){
        static const Profile profiles[]={
            {GameId::Gaiden1,0xd145,0xd0ae,0x10c4,0xee7a,0x9373,0x1318,0x1346,0xd0fa,0xc960,0x2333,0xd092,0x2644},
            {GameId::Gaiden2,0xd054,0xcfbd,0x0f20,0xf09d,0x8f7c,0x1175,0x11a3,0xd009,0xcd39,0x232e,0xcf9f,0x26ae}
        };
        auto id=identifyGame(rom).id;for(const auto& p:profiles)if(p.id==id)return &p;return nullptr;
    }
public:
    static bool recognizes(const std::vector<char>& rom){
        const auto* p=profile(rom);if(!p||rom.size()<0x14d90)return false;
        auto lo=[](unsigned n){return static_cast<unsigned char>(n);};auto hi=[](unsigned n){return static_cast<unsigned char>(n>>8);};
        const unsigned char level[]={0x11,lo(p->firstMp),hi(p->firstMp),0xfe,7,0x38,5,0x11,lo(p->firstMp+7),hi(p->firstMp+7),0xd6,7,0x6f,0x26,0,0x19,0xc9};
        const unsigned char field[]={0xf5,0xcd,lo(p->load),hi(p->load),0xfa,lo(p->scratch),hi(p->scratch),0xcd,lo(p->level),hi(p->level),0x35,0xf1,0xc3,lo(p->save),hi(p->save)};
        const unsigned char menu[]={0xfa,lo(p->menuFlag),hi(p->menuFlag),0xb7,0x28,9,0x3e,0x64,0xcd,lo(p->random),hi(p->random),0xfe,0x32,0x30,3,0xf1,0xb7,0xc9,0x35,1,6,0};
        const unsigned char battle[]={0x21,lo(p->battleScratch),hi(p->battleScratch),0x19,0x7e,0xb7,0x20,6,0xf0,0x8e,0xcd,0x6d,0x4d,0x35,0xf1,0xcd,lo(p->save),hi(p->save)};
        const unsigned char spellLevel[]={0x3d,0x21,lo(p->counts),hi(p->counts),0x11,lo(p->firstMp),hi(p->firstMp),0xcb,0x7f,0x28,6,0x21,lo(p->counts+7),hi(p->counts+7),0x11,lo(p->firstMp+7),hi(p->firstMp+7),0x0e,0,0xe6,0x7f,0x28,7,0x96,0x23,0x38,3,0x0c,0x18,0xf9,0x69,0x26,0,0x19,0xc9};
        auto matches=[&](size_t at,const auto& bytes){return std::equal(std::begin(bytes),std::end(bytes),reinterpret_cast<const unsigned char*>(rom.data()+at));};
        return matches(p->level,level)&&matches(p->field,field)&&matches(p->menu,menu)&&matches(0x14d33,battle)&&matches(0x14d6d,spellLevel);
    }
    void attach(const std::vector<char>& rom){supported_=recognizes(rom);profile_=supported_?profile(rom):nullptr;enabled_=false;}
    bool supported()const{return supported_;}
    bool enabled()const{return enabled_;}
    bool enable(bool value){if(value&&!supported_)return false;enabled_=value;return true;}
    bool write(gambatte::GB& core,unsigned pc,unsigned address,unsigned value)const{
        if(!enabled_||!profile_||address<profile_->firstMp||address>=profile_->firstMp+14)return true;
        auto ram=static_cast<const unsigned char*>(core.rambank0_ptr());unsigned bank=ram[profile_->bankAddress-0xc000];
        unsigned fieldPc=(profile_->field&0x3fff)+0x4000+11,menuPc=(profile_->menu&0x3fff)+0x4000+19;
        if(!((bank==2&&pc==menuPc)||(bank==3&&pc==fieldPc)||(bank==5&&pc==0x4d41)))return true;
        return value!=static_cast<unsigned char>(ram[address-0xc000]-1);
    }
};
