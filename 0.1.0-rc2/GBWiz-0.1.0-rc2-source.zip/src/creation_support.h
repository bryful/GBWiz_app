#pragma once
#include "game_support.h"

class CreationSupport {
    bool supported_=false,maximum_=false;
    unsigned rolls_=0;
public:
    static constexpr unsigned maximumBonus=30; // (random % 4) + 7 + 10 + 10.
    static bool recognizes(const std::vector<char>& rom){
        if(identifyGame(rom).id!=GameId::Gaiden1||rom.size()<0x18000)return false;
        const unsigned char roll[]={0x3e,4,0xcd,0x33,0x23,0xc6,7,0x47,0x3e,0x14,0xcd,0x33,0x23,0xfe,0x0a,0x20,4,0x3e,0x0a,0x80,0x47,0x3e,0x14,0xcd,0x33,0x23,0xfe,0x0a,0x20,4,0x3e,0x0a,0x80,0x47,0x78,0xea,0xfa,0xd0,0xcd,0xd3,0x6f};
        const unsigned char display[]={0x5f,0x16,0,0xcd,0xef,1};
        const unsigned char store[]={0x7b,0x22,0x7a,0x22,0x79,0x22,0x78,0x77};
        const unsigned char formatter[]={0x01,0,0,0x21,0xc0,0xd0,0xcd,0x08,0x03};
        auto matches=[&](size_t at,const auto& bytes){return std::equal(std::begin(bytes),std::end(bytes),reinterpret_cast<const unsigned char*>(rom.data()+at));};
        return matches(0x16e1b,roll)&&matches(0x16fd3,display)&&matches(0x0308,store)&&matches(0x01ef,formatter);
    }
    void attach(const std::vector<char>& rom){supported_=recognizes(rom);maximum_=false;rolls_=0;}
    bool supported()const{return supported_;}
    bool enabled()const{return maximum_;}
    unsigned rolls()const{return rolls_;}
    bool enable(bool value){if(value&&!supported_)return false;maximum_=value;return true;}
    bool write(gambatte::GB& core,unsigned pc,unsigned sp,unsigned address,unsigned value){
        if(!supported_)return true;
        auto ram=static_cast<unsigned char*>(core.rambank0_ptr());
        if(ram[0x10ae]!=5)return true;
        if(pc==0x6e41&&address==0xd0fa){
            ++rolls_;
            if(maximum_){ram[0x10fa]=maximumBonus;return false;}
        }
        // The initial formatter receives the original roll in A. Correct its
        // scratch value too; subsequent displays use the remaining RAM value.
        if(maximum_&&pc==0x0310&&address==0xd0c3&&sp>=0xc000&&sp<=0xdffc){
            auto stack=ram+sp-0xc000;
            if(stack[0]==0xf8&&stack[1]==1&&stack[2]==0xd9&&stack[3]==0x6f){
                ram[0x10c0]=ram[0x10fa];ram[0x10c1]=ram[0x10c2]=0;
            }
        }
        return true;
    }
};
