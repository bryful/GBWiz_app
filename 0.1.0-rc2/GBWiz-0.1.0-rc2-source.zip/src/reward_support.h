#pragma once
#include "game_support.h"
#include <cstdint>
#include <limits>

// Scale the original per-recipient battle reward after division. The game's
// own display, eligibility checks, saturating addition and save code follow.
class RewardSupport {
    bool supported_=false;
    unsigned experience_=1,gold_=1;
    unsigned experienceEvents_=0,goldEvents_=0;
    uint32_t baseExperience_=0,baseGold_=0;
public:
    static bool valid(unsigned value){return value==1||value==8||value==16||value==32||value==64||value==128||value==256;}
    static bool recognizes(const std::vector<char>& rom){
        if(identifyGame(rom).id!=GameId::Gaiden1||rom.size()<0x13000)return false;
        const unsigned char store[]={0x7b,0x22,0x7a,0x22,0x79,0x22,0x78,0x77,0x2b,0x2b,0x2b,0xc9};
        const unsigned char exp[]={0x21,0x68,0xd0,0xcd,0x08,0x03,0x21,0x68,0xd0,0x11,0xc0,0xd0,0x01,0x04,0x00,0xcd,0x85,0x21};
        const unsigned char gold[]={0x01,0,0,0x21,0xc0,0xd0,0xcd,0x08,0x03,0xaf,0xf5,0xcd,0xb0,0x0e};
        auto matches=[&](size_t at,const auto& bytes){return std::equal(std::begin(bytes),std::end(bytes),reinterpret_cast<const unsigned char*>(rom.data()+at));};
        return matches(0x0308,store)&&matches(0x12aa9,exp)&&matches(0x12bca,gold);
    }
    void attach(const std::vector<char>& rom){supported_=recognizes(rom);experience_=gold_=1;experienceEvents_=goldEvents_=0;baseExperience_=baseGold_=0;}
    bool supported()const{return supported_;}
    bool set(unsigned experience,unsigned gold){
        if(!valid(experience)||!valid(gold)||(!supported_&&(experience!=1||gold!=1)))return false;
        experience_=experience;gold_=gold;return true;
    }
    unsigned experience()const{return experience_;}
    unsigned gold()const{return gold_;}
    unsigned experienceEvents()const{return experienceEvents_;}
    unsigned goldEvents()const{return goldEvents_;}
    uint32_t baseExperience()const{return baseExperience_;}
    uint32_t baseGold()const{return baseGold_;}
    bool write(gambatte::GB& core,unsigned pc,unsigned sp,unsigned address,unsigned value){
        if(!supported_||pc!=0x0310||(address!=0xd06b&&address!=0xd0c3)||sp<0xc000||sp>=0xdfff)return true;
        auto ram=static_cast<unsigned char*>(core.rambank0_ptr());
        if(ram[0x10ae]!=4)return true;
        unsigned caller=ram[sp-0xc000]|(unsigned(ram[sp-0xc000+1])<<8);
        unsigned factor;
        if(address==0xd06b&&caller==0x6aaf){factor=experience_;++experienceEvents_;}
        else if(address==0xd0c3&&caller==0x6bd3){factor=gold_;++goldEvents_;}
        else return true;
        auto target=ram+address-0xc000-3;
        uint64_t original=uint64_t(target[0])|(uint64_t(target[1])<<8)|(uint64_t(target[2])<<16)|(uint64_t(value)<<24);
        if(address==0xd06b)baseExperience_=static_cast<uint32_t>(original);else baseGold_=static_cast<uint32_t>(original);
        if(factor==1)return true;
        uint64_t result=std::min<uint64_t>(original*factor,std::numeric_limits<uint32_t>::max());
        for(unsigned i=0;i<4;i++)target[i]=static_cast<unsigned char>(result>>(8*i));
        return false; // All four scratch bytes are now stored; CPU timing stays unchanged.
    }
};
