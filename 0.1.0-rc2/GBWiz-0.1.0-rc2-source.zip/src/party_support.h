#pragma once
#include "game_support.h"

class PartySupport {
    struct Profile {GameId id;unsigned check,caller,partyLast,alignment,reject;};
    gambatte::GB* core_=nullptr;
    bool supported_=false,enabled_=false;
    const Profile* profile_=nullptr;
    static const Profile* profile(const std::vector<char>& rom){
        static const Profile profiles[]={
            {GameId::Gaiden1,0x12e7,0xaa75,0xc955,0xd10e,0x69df},
            {GameId::Gaiden2,0x1144,0xa673,0xcd2e,0xd01d,0x65dd},
            {GameId::Gaiden3,0x0ff0,0xa969,0xc9b4,0xcb29,0x68d3}
        };
        auto id=identifyGame(rom).id;for(const auto& p:profiles)if(p.id==id)return &p;return nullptr;
    }
    static std::string patch(unsigned address,unsigned value,unsigned expected){
        const char* hex="0123456789ABCDEF";std::string code="000-000-000";
        code[0]=hex[value>>4];code[1]=hex[value&15];code[2]=hex[(address>>8)&15];
        code[4]=hex[(address>>4)&15];code[5]=hex[address&15];code[6]=hex[((address>>12)^15)&15];
        unsigned compare=expected^0x45;compare=(((compare<<2)|(compare>>6))^255)&255;
        code[8]=hex[compare>>4];code[10]=hex[compare&15];return code;
    }
public:
    static bool recognizes(const std::vector<char>& rom){
        const auto* p=profile(rom);
        if(!p||rom.size()<p->caller+16||rom.size()>0x80000||static_cast<unsigned char>(rom[0x147])!=3)return false;
        const unsigned char check[]={0xb7,0x3d,0xc8,0x3c,0x4f,0x21,static_cast<unsigned char>(p->partyLast),static_cast<unsigned char>(p->partyLast>>8),6,6,0x16,0,0x3a,7,7,0xe6,3,0xfe,3,0x28,9,0xfe,1,0x28,5,0xb9,0x28,2,0x37,0xc9,5,0x20,0xeb,0xb7,0xc9};
        const unsigned char caller[]={0xfa,static_cast<unsigned char>(p->alignment),static_cast<unsigned char>(p->alignment>>8),0x5f,0xcb,0x0b,0xcb,0x0b,0xe5,0xcd,static_cast<unsigned char>(p->check),static_cast<unsigned char>(p->check>>8),0xe1,0xda,static_cast<unsigned char>(p->reject),static_cast<unsigned char>(p->reject>>8)};
        auto matches=[&](size_t at,const auto& bytes){return std::equal(std::begin(bytes),std::end(bytes),reinterpret_cast<const unsigned char*>(rom.data()+at));};
        return matches(p->check,check)&&matches(p->caller,caller);
    }
    void detach(){if(core_&&enabled_)core_->clearCheats();core_=nullptr;profile_=nullptr;supported_=enabled_=false;}
    void attach(gambatte::GB& core,const std::vector<char>& rom){detach();core_=&core;supported_=recognizes(rom);if(supported_)profile_=profile(rom);}
    bool supported()const{return supported_;}
    bool enabled()const{return enabled_;}
    bool enable(bool value){
        if(value&&(!supported_||!core_))return false;
        if(value==enabled_)return true;
        // Existing Gambatte Game Genie support provides an undo list. These
        // compare-qualified codes change only the profile's B7 -> AF, 3D -> C9,
        // making the alignment-only check return carry clear. ROM files and
        // character/party data are untouched. This app uses no other cheats.
        if(value)core_->setGameGenie(patch(profile_->check,0xaf,0xb7)+";"+patch(profile_->check+1,0xc9,0x3d));
        else core_->clearCheats();
        enabled_=value;return true;
    }
};
