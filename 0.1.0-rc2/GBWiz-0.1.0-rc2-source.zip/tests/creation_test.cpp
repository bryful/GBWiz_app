#include "turbo_runner.h"
#include <iostream>
void cartridge_set_rumble(unsigned){}
void require(bool ok,const char* text){if(!ok)throw std::runtime_error(text);}
struct Input:gambatte::InputGetter{unsigned value=0;unsigned operator()()override{return value;}};
struct Session{
    Input input;std::unique_ptr<gambatte::GB> core;TurboRunner turbo;
    std::array<gambatte::video_pixel_t,160*144> pixels{};
    std::array<gambatte::uint_least32_t,40000> sound{};
    Session(const std::vector<char>& rom,const std::vector<char>& state,bool enabled,int speed=2):core(loadCoreBytes(rom,&input)){
        require(core->loadState(state.data(),state.size()),"Creation checkpoint rejected");turbo.attach(*core,rom,identifyGame(rom));
        require(turbo.creation().enable(enabled)&&turbo.speed(speed),"Creation settings rejected");
    }
    unsigned char* ram(){return static_cast<unsigned char*>(core->rambank0_ptr());}
    void run(unsigned key,unsigned frames){for(unsigned f=0;f<frames;f++)turbo.run(key,input.value,pixels,sound);}
    void press(unsigned key,unsigned wait=60){run(key,4);run(0,wait);}
    void choose(unsigned race){for(unsigned i=0;i<race;i++)press(128);press(1,120);press(1,120);}
};
int wmain(int argc,wchar_t** argv)try{
    require(argc==3,"Expected Gaiden 1 ROM and race-selection checkpoint");auto rom=read(argv[1]),state=read(argv[2]);
    require(CreationSupport::recognizes(rom),"Creation driver not recognized");
    auto unknown=rom;unknown[0x16e1b]^=1;require(!CreationSupport::recognizes(unknown),"Unknown creation revision accepted");
    for(unsigned race=0;race<5;race++)for(unsigned delay:{0u,17u,59u}){
        Session normal(rom,state,false),maximum(rom,state,true);normal.run(0,delay);maximum.run(0,delay);normal.choose(race);maximum.choose(race);
        require(maximum.turbo.creation().rolls()==1&&maximum.ram()[0x10fa]==30,"Maximum bonus was not generated exactly once");
        require(normal.ram()[0x10fa]>=7&&normal.ram()[0x10fa]<=30,"Original bonus range changed");
        require(maximum.ram()[0x110c]==race,"Wrong race selected");
        require(std::equal(maximum.ram()+0x1112,maximum.ram()+0x1118,normal.ram()+0x1112),"Race base attributes were modified");
        require(std::memcmp(maximum.core->savedata_ptr(),normal.core->savedata_ptr(),normal.core->savedata_size())==0,"Generation modified saved characters");
    }
    for(int speed:{3,4,6,8}){Session s(rom,state,true,speed);s.choose(0);require(s.ram()[0x10fa]==30&&s.turbo.creation().rolls()==1,"Turbo creation bonus failed");}
    Session s(rom,state,true);s.choose(0);auto base=std::array<unsigned char,6>{};std::copy(s.ram()+0x1112,s.ram()+0x1118,base.begin());
    s.press(16);require(s.ram()[0x10fa]==29&&s.ram()[0x1112]==base[0]+1,"Spending a bonus point failed");
    auto spent=s.turbo.saveState();s.press(32);require(s.ram()[0x10fa]==30,"Refunding a bonus point failed");
    require(s.turbo.loadState(spent)&&s.ram()[0x10fa]==29,"State restore refilled spent bonus points");s.press(32);
    for(unsigned stat=0;stat<3;stat++){for(unsigned i=0;i<10;i++)s.press(16,30);if(stat<2)s.press(128,30);}
    require(s.ram()[0x10fa]==0,"Could not spend all thirty points");
    unsigned total=0;for(unsigned i=0;i<6;i++){require(s.ram()[0x1112+i]<=18,"Original attribute cap was exceeded");total+=s.ram()[0x1112+i]-base[i];}
    require(total==30,"Allocated attributes do not total thirty bonus points");
    auto final=std::array<unsigned char,6>{};std::copy(s.ram()+0x1112,s.ram()+0x1118,final.begin());
    unsigned empty=20;for(unsigned i=0;i<20;i++)if(s.ram()[0x1186+i*128]==0){empty=i;break;}
    require(empty<20,"Roster fixture is full");
    s.press(1,120);s.press(1,120);s.press(1,120);
    auto record=s.ram()+0x1186+empty*128;
    require(record[0]!=0&&std::equal(final.begin(),final.end(),record+0x0e),"Created character did not retain allocated attributes");
    // OFF must be identical to the unmodified core, including RNG and timing.
    Session off(rom,state,false);Input input;auto reference=loadCoreBytes(rom,&input);reference->loadState(state.data(),state.size());
    for(unsigned f=0;f<248;f++){unsigned key=f<4||(f>=124&&f<128)?1:0;off.run(key,1);input.value=key;unsigned count=35112;reference->runFor(off.pixels.data(),160,off.sound.data(),off.sound.size(),count);}
    std::vector<char> a(off.core->stateSize()),b(reference->stateSize());off.core->saveState(a.data());reference->saveState(b.data());require(a==b,"OFF changed original creation behavior");
    std::cout<<"PASS: five races, varied RNG, all speeds, spend/refund, state restore, creation/save and OFF identical to original\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 1;}
