// Render editable SVG concepts with sharp. Pass a directory containing sharp
// as the first argument, or install sharp locally and omit that argument.
const fs = require('fs');
const path = require('path');
const sharp = require(process.argv[2] ? path.join(process.argv[2], 'sharp') : 'sharp');
const root = path.resolve(__dirname, '..');
(async () => {
  for (const variant of ['a', 'b', 'c']) {
    await sharp(path.join(root, `assets/icons/concept-${variant}.svg`)).png().toFile(path.join(root, `assets/icons/concept-${variant}.png`));
  }
  for (const [density, size] of [['mdpi',48],['hdpi',72],['xhdpi',96],['xxhdpi',144],['xxxhdpi',192]]) {
    const directory = path.join(root, 'android/app/src/main/res', `mipmap-${density}`);
    fs.mkdirSync(directory, {recursive:true});
    await sharp(path.join(root, 'assets/icons/concept-a.svg')).resize(size,size).png().toFile(path.join(directory,'ic_launcher.png'));
  }
})().catch(error => { console.error(error); process.exit(1); });
