#include "turbo_runner.h"
#include <iostream>
void cartridge_set_rumble(unsigned){}
void require(bool ok,const char* text){if(!ok)throw std::runtime_error(text);}
int wmain(int argc,wchar_t** argv)try{
    require(argc==3,"Expected ROM and town state");auto rom=read(argv[1]),state=read(argv[2]);
    require(MpSupport::recognizes(rom),"MP revision not recognized");
    auto source=loadCoreBytes(rom,nullptr);require(source->loadState(state.data(),state.size()),"Town fixture rejected");
    auto privateRom=rom;privateRom[0x100]=char(0xc3);privateRom[0x101]=0;privateRom[0x102]=char(0xc0);
    // Keep the original DEC and its PC; return before unrelated menu/battle UI.
    privateRom[0x9386]=privateRom[0x14d41]=char(0xc9);
    std::array<gambatte::video_pixel_t,160*144> pixels{};std::array<gambatte::uint_least32_t,40000> sound{};
    for(unsigned site=0;site<3;site++)for(unsigned selected=0;selected<6;selected++)for(int speed:{2,3,4,6,8}){
        auto core=loadCoreBytes(privateRom,nullptr);auto ram=static_cast<unsigned char*>(core->rambank0_ptr());
        std::memcpy(ram,source->rambank0_ptr(),8192);std::memcpy(core->savedata_ptr(),source->savedata_ptr(),8192);
        for(unsigned slot=0;slot<6;slot++)std::fill(ram+0x1186+128*slot+0x41,ram+0x1186+128*slot+0x4f,5);
        auto before=std::vector<unsigned char>(ram+0x1186,ram+0x1186+20*128);
        unsigned bank=site==0?3:site==1?2:5;
        std::vector<unsigned char> code={0xf3,0x31,0xf0,0xcf,0x3e,static_cast<unsigned char>(bank),0xea,0,0x20,0xea,0xae,0xd0};
        unsigned wait=code.size();code.insert(code.end(),{0xfa,0x81,0xc3,0xb7,0x28,0xfa,0xaf,0xea,0x81,0xc3});
        for(unsigned level=0;level<14;level++){
            if(site==0){
                const unsigned char call[]={0x3e,static_cast<unsigned char>(level),0xea,0xfa,0xd0,0x3e,static_cast<unsigned char>(selected),0xcd,0x7a,0x6e};code.insert(code.end(),std::begin(call),std::end(call));
            }else{
                const unsigned char load[]={0x3e,static_cast<unsigned char>(selected),0xcd,0x18,0x13};code.insert(code.end(),std::begin(load),std::end(load));
                unsigned number=level;
                if(site==2){number=1+(level>=7?128:0);for(unsigned i=(level/7)*7;i<level;i++)number+=static_cast<unsigned char>(rom[0x2644+i]);}
                const unsigned char call[]={0x3e,static_cast<unsigned char>(number),0xcd,static_cast<unsigned char>(site==1?0xc4:0x6d),static_cast<unsigned char>(site==1?0x10:0x4d),0xcd,static_cast<unsigned char>(site==1?0x85:0x40),static_cast<unsigned char>(site==1?0x53:0x4d),0x3e,static_cast<unsigned char>(selected),0xcd,0x46,0x13};code.insert(code.end(),std::begin(call),std::end(call));
            }
        }
        code.insert(code.end(),{0x21,0x82,0xc3,0x34,0xc3,static_cast<unsigned char>(wait),0xc0});
        require(code.size()<0x380,"Test program too long");std::copy(code.begin(),code.end(),ram);ram[0x381]=ram[0x382]=0;
        TurboRunner runner;runner.attach(*core,rom,identifyGame(rom));require(!runner.mp().enabled(),"MP support defaults to ON");require(runner.speed(speed),"Speed rejected");
        unsigned input=0;runner.run(0,input,pixels,sound);
        for(unsigned phase=0;phase<3;phase++){
            bool enabled=phase==1;require(runner.mp().enable(enabled),"Global toggle rejected");ram[0x381]=1;
            for(unsigned f=0;f<30&&ram[0x382]!=phase+1;f++)runner.run(0,input,pixels,sound);
            require(ram[0x382]==phase+1,"Original routines did not finish");
            auto save=static_cast<const unsigned char*>(core->savedata_ptr());unsigned expected=phase<2?4:3;
            for(unsigned slot=0;slot<20;slot++)for(unsigned i=0;i<128;i++){
                bool mp=slot==selected&&i>=0x41&&i<0x4f;
                require(ram[0x1186+slot*128+i]==(mp?expected:before[slot*128+i]),"MP or unrelated character field incorrect");
                if(mp)require(save[0x17+slot*128+i]==expected,"Original save lost MP");
            }
            auto checkpoint=runner.saveState();require(runner.mp().enable(!enabled)&&runner.loadState(checkpoint)&&runner.mp().enabled()==!enabled,"State load replaced the global setting");
        }
    }
    // OFF must execute exactly like the original core, not just yield equal MP.
    {
        auto core=loadCoreBytes(rom,nullptr),reference=loadCoreBytes(rom,nullptr);core->loadState(state.data(),state.size());reference->loadState(state.data(),state.size());
        TurboRunner runner;runner.attach(*core,rom,identifyGame(rom));unsigned input=0;
        for(unsigned f=0;f<120;f++){runner.run(0,input,pixels,sound);unsigned count=35112;reference->runFor(pixels.data(),160,sound.data(),sound.size(),count);}
        std::vector<char> expected(reference->stateSize());reference->saveState(expected.data());require(runner.saveState()==expected,"OFF changed original emulation");
        require(runner.mp().enable(true),"Enable failed");auto ram=static_cast<unsigned char*>(core->rambank0_ptr());ram[0x1145]=5;
        require(runner.mp().write(*core,0x6e85,0xd145,4),"Wrong bank was intercepted");ram[0x10ae]=3;
        require(runner.mp().write(*core,0x6e86,0xd145,4)&&runner.mp().write(*core,0x6e85,0xd144,4)&&runner.mp().write(*core,0x6e85,0xd145,9),"Unrelated/recovery write was intercepted");
    }
    for(unsigned offset:{0x10c4u,0xee7au,0x9373u,0x14d33u,0x14d6du}){auto unknown=rom;unknown[offset]^=1;MpSupport mp;mp.attach(unknown);require(!mp.supported()&&!mp.enable(true)&&mp.enable(false),"Unknown revision enabled");}
    std::cout<<"PASS: global OFF/ON/OFF, six characters, 14 levels, three original consumption paths, five speeds, original save, current setting on state load, OFF identical, unrelated/recovery writes preserved\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 1;}
