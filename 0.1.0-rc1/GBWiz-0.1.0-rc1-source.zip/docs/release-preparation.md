# 0.1.0-rc1 リリース準備記録

## 準備したもの

- アイコン3案（assets/icons/concepts.png）。Aを暫定採用し、SVG・PNG・Windows ICO・Android adaptive iconを収録。
- Windowsのファイル／製品バージョン0.1.0-rc1と埋込アイコン。
- AndroidのversionCode=2、versionName=0.1.0-rc1。releaseは非debuggable、開発版は名前・バージョンに開発版の表示。
- Windows ZIP、Android未署名release APK、対応ソースZIP、3種のライセンス、操作説明、リリースノートを作るpackage.ps1。
- GBWiz専用鍵を指定し、環境変数でパスワードを渡すsign-release.ps1。署名は未実行。

## 検証

- アイコン追加後のWindows Releaseビルドと全21テストが成功。
- Android ARM64／x86_64のrelease・debug・テストAPKのビルド成功、releaseのlintVital成功。
- release APKのアプリ名GBWiz、バージョン、アイコン参照、2 ABIをaapt2とZIP内容で確認。debuggable表示と署名ファイルがないことを確認。
- Pixel 9aの開発版を更新し、ランチャーアイコンの実描画・設定・キャラクター操作・縦横メニューの計10テスト成功。
- package.ps1・sign-release.ps1のPowerShell構文を確認。

## 正式リリース前の残件

1. アイコンの最終選択。
2. GBWiz専用のAndroid署名鍵・保管先の確定と署名。AGENTS.mdは同階層GBWiz_signingを指定しています。既存のWiiz_signingの鍵は流用していません。
3. 正式署名したrelease APK自体の端末起動・更新経路の確認。今回の実機検証は開発版で実施しています。
4. Windowsの開発環境以外での起動確認と実物コントローラー等の確認。
5. Android初期ROMフォルダのDocuments/NesDQ指定と、現状Documents/GBWiz/romの整合。

この段階はリリース候補の準備で、正式署名・公開は行っていません。後続の作品別機能展開は、この候補とは分けて進めます。
