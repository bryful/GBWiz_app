param(
    [string]$InputApk = 'android\app\build\outputs\apk\release\app-release-unsigned.apk',
    [string]$OutputApk = 'build\GBWiz-0.1.0-rc1.apk',
    [string]$Keystore = '..\GBWiz_signing\GBWiz-release.jks',
    [string]$KeyAlias = 'gbwiz',
    [string]$SdkPath = $env:ANDROID_HOME
)
$ErrorActionPreference = 'Stop'
if (!$SdkPath) { $SdkPath = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (!(Test-Path -LiteralPath $Keystore)) { throw 'GBWiz release keystore is not prepared. Use a GBWiz-specific key in the AGENTS.md signing directory.' }
if (!(Test-Path -LiteralPath $InputApk)) { throw 'Unsigned release APK not found. Build assembleRelease first.' }
if (Test-Path -LiteralPath $OutputApk) { throw 'Output APK already exists; choose another output path.' }
if (!$env:GBWIZ_STORE_PASSWORD -or !$env:GBWIZ_KEY_PASSWORD) { throw 'Set GBWIZ_STORE_PASSWORD and GBWIZ_KEY_PASSWORD locally before signing.' }
$signer = Join-Path $SdkPath 'build-tools\36.0.0\apksigner.bat'
& $signer sign --ks $Keystore --ks-key-alias $KeyAlias --ks-pass env:GBWIZ_STORE_PASSWORD --key-pass env:GBWIZ_KEY_PASSWORD --out $OutputApk $InputApk
if ($LASTEXITCODE -ne 0) { throw 'APK signing failed.' }
& $signer verify --verbose $OutputApk
if ($LASTEXITCODE -ne 0) { throw 'APK signature verification failed.' }
