param([string]$Version='0.1.0-rc1',[switch]$SkipBuild,[switch]$IncludeAndroidRelease)
$ErrorActionPreference='Stop'
if($Version -notmatch '^\d+\.\d+\.\d+(?:-[a-zA-Z0-9.-]+)?$'){throw 'Invalid release version.'}
if(!$SkipBuild){& (Join-Path $PSScriptRoot 'build.ps1')}
$destination=Join-Path ([IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\GBWiz_app'))) $Version
if(Test-Path -LiteralPath $destination){throw "Release folder already exists; preserve it and choose another version: $destination"}
$required=@('build\Release\GBWiz.exe','build\Release\SDL2.dll','docs\release-notes.md','docs\release-guide.md','sign-release.ps1')
if($IncludeAndroidRelease){$required+='android\app\build\outputs\apk\release\app-release-unsigned.apk'}
foreach($file in $required){if(!(Test-Path -LiteralPath (Join-Path $PSScriptRoot $file))){throw "Missing release input: $file"}}
$windows=Join-Path $destination 'Windows'
New-Item -ItemType Directory -Path (Join-Path $windows 'Rom') -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'build\Release\GBWiz.exe'),(Join-Path $PSScriptRoot 'build\Release\SDL2.dll') -Destination $windows
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'docs\release-guide.md') -Destination (Join-Path $windows 'README.md')
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'third_party\gambatte\COPYING') -Destination (Join-Path $destination 'COPYING.txt')
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'third_party\SDL2-2.32.10\LICENSE.txt') -Destination (Join-Path $destination 'SDL2-LICENSE.txt')
$blipper=Get-Content -Raw -Encoding UTF8 (Join-Path $PSScriptRoot 'third_party\gambatte\libgambatte\libretro\blipper.c')
$blipper.Substring(0,$blipper.IndexOf('*/')+2) | Set-Content -Encoding UTF8 (Join-Path $destination 'blipper-LICENSE.txt')
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'docs\release-notes.md') -Destination (Join-Path $destination 'RELEASE-NOTES.md')
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'docs\release-guide.md') -Destination (Join-Path $destination 'README.md')
if($IncludeAndroidRelease){
 $androidOutput=Join-Path $destination 'Android'
 New-Item -ItemType Directory -Path $androidOutput | Out-Null
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'android\app\build\outputs\apk\release\app-release-unsigned.apk') -Destination (Join-Path $androidOutput "GBWiz-$Version-unsigned.apk")
}
# Corresponding source snapshot: allowlist excludes all game data and secrets.
$stage=Join-Path $PSScriptRoot ('build\release-source-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $stage | Out-Null
foreach($name in @('src','tests','tools','resources','assets','docs','CMakeLists.txt','build.ps1','build-android.ps1','package.ps1','sign-release.ps1','README.md')){
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $stage -Recurse
}
$androidSource=Join-Path $stage 'android'
New-Item -ItemType Directory -Path $androidSource | Out-Null
foreach($name in @('build.gradle','settings.gradle','gradle.properties','gradlew','gradlew.bat','README.md','gradle')){
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot "android\$name") -Destination $androidSource -Recurse
}
New-Item -ItemType Directory -Path (Join-Path $androidSource 'app') | Out-Null
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'android\app\build.gradle'),(Join-Path $PSScriptRoot 'android\app\src') -Destination (Join-Path $androidSource 'app') -Recurse
$vendorStage=Join-Path $stage 'third_party\gambatte'
New-Item -ItemType Directory -Path $vendorStage -Force | Out-Null
Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'third_party\gambatte') -Force | Where-Object {$_.Name -ne '.git'} | Copy-Item -Destination $vendorStage -Recurse
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'third_party\SDL2-2.32.10') -Destination (Join-Path $stage 'third_party') -Recurse
$forbidden=Get-ChildItem -LiteralPath $stage -Recurse -File | Where-Object {$_.Name -match '\.(gb|gbc|nes|sav|state|jks|keystore|p12|pem)$' -or $_.Name -eq 'local.properties'}
if($forbidden){throw 'Source stage contains excluded game data or signing material.'}
Compress-Archive -Path (Join-Path $stage '*') -DestinationPath (Join-Path $destination "GBWiz-$Version-source.zip")
Compress-Archive -Path $windows,(Join-Path $destination 'COPYING.txt'),(Join-Path $destination 'SDL2-LICENSE.txt'),(Join-Path $destination 'blipper-LICENSE.txt') -DestinationPath (Join-Path $destination "GBWiz-$Version-Windows.zip")
$hashLines=Get-ChildItem -LiteralPath $destination -File -Recurse | ForEach-Object {
 $relative=$_.FullName.Substring($destination.Length+1).Replace('\','/')
 '{0}  {1}' -f (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant(),$relative
}
$hashLines | Set-Content -Encoding UTF8 (Join-Path $destination 'SHA256SUMS.txt')
Write-Output "Release candidate prepared: $destination"
