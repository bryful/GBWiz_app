#pragma once
#include "game_support.h"

class PartySupport {
    gambatte::GB* core_=nullptr;
    bool supported_=false,enabled_=false;
public:
    static bool recognizes(const std::vector<char>& rom){
        if(identifyGame(rom).id!=GameId::Gaiden1||rom.size()<0xaa85||rom.size()>0x80000||static_cast<unsigned char>(rom[0x147])!=3)return false;
        const unsigned char check[]={0xb7,0x3d,0xc8,0x3c,0x4f,0x21,0x55,0xc9,6,6,0x16,0,0x3a,7,7,0xe6,3,0xfe,3,0x28,9,0xfe,1,0x28,5,0xb9,0x28,2,0x37,0xc9,5,0x20,0xeb,0xb7,0xc9};
        const unsigned char caller[]={0xfa,0x0e,0xd1,0x5f,0xcb,0x0b,0xcb,0x0b,0xe5,0xcd,0xe7,0x12,0xe1,0xda,0xdf,0x69};
        auto matches=[&](size_t at,const auto& bytes){return std::equal(std::begin(bytes),std::end(bytes),reinterpret_cast<const unsigned char*>(rom.data()+at));};
        return matches(0x12e7,check)&&matches(0xaa75,caller);
    }
    void detach(){if(core_&&enabled_)core_->clearCheats();core_=nullptr;supported_=enabled_=false;}
    void attach(gambatte::GB& core,const std::vector<char>& rom){detach();core_=&core;supported_=recognizes(rom);}
    bool supported()const{return supported_;}
    bool enabled()const{return enabled_;}
    bool enable(bool value){
        if(value&&(!supported_||!core_))return false;
        if(value==enabled_)return true;
        // Existing Gambatte Game Genie support provides an undo list. These
        // compare-qualified codes change only 12E7:B7 -> AF and 12E8:3D -> C9,
        // making the alignment-only check return carry clear. ROM files and
        // character/party data are untouched. This app uses no other cheats.
        if(value)core_->setGameGenie("AF2-E7E-304;C92-E8E-10E");
        else core_->clearCheats();
        enabled_=value;return true;
    }
};
