#pragma once
#include "game_support.h"

// A single global setting: suppress only the game's three spell MP decrements.
// Loading/saving, recovery, MP loss events and all other writes stay original.
class MpSupport {
    bool supported_=false,enabled_=false;
public:
    static bool recognizes(const std::vector<char>& rom){
        if(identifyGame(rom).id!=GameId::Gaiden1||rom.size()<0x14d90)return false;
        const unsigned char level[]={0x11,0x45,0xd1,0xfe,7,0x38,5,0x11,0x4c,0xd1,0xd6,7,0x6f,0x26,0,0x19,0xc9};
        const unsigned char field[]={0xf5,0xcd,0x18,0x13,0xfa,0xfa,0xd0,0xcd,0xc4,0x10,0x35,0xf1,0xc3,0x46,0x13};
        const unsigned char menu[]={0xfa,0x60,0xc9,0xb7,0x28,9,0x3e,0x64,0xcd,0x33,0x23,0xfe,0x32,0x30,3,0xf1,0xb7,0xc9,0x35,1,6,0};
        const unsigned char battle[]={0x21,0x92,0xd0,0x19,0x7e,0xb7,0x20,6,0xf0,0x8e,0xcd,0x6d,0x4d,0x35,0xf1,0xcd,0x46,0x13};
        const unsigned char spellLevel[]={0x3d,0x21,0x44,0x26,0x11,0x45,0xd1,0xcb,0x7f,0x28,6,0x21,0x4b,0x26,0x11,0x4c,0xd1,0x0e,0,0xe6,0x7f,0x28,7,0x96,0x23,0x38,3,0x0c,0x18,0xf9,0x69,0x26,0,0x19,0xc9};
        auto matches=[&](size_t at,const auto& bytes){return std::equal(std::begin(bytes),std::end(bytes),reinterpret_cast<const unsigned char*>(rom.data()+at));};
        return matches(0x10c4,level)&&matches(0xee7a,field)&&matches(0x9373,menu)&&matches(0x14d33,battle)&&matches(0x14d6d,spellLevel);
    }
    void attach(const std::vector<char>& rom){supported_=recognizes(rom);enabled_=false;}
    bool supported()const{return supported_;}
    bool enabled()const{return enabled_;}
    bool enable(bool value){if(value&&!supported_)return false;enabled_=value;return true;}
    bool write(gambatte::GB& core,unsigned pc,unsigned address,unsigned value)const{
        if(!enabled_||!supported_||address<0xd145||address>0xd152)return true;
        auto ram=static_cast<const unsigned char*>(core.rambank0_ptr());
        unsigned bank=ram[0x10ae];
        if(!((bank==2&&pc==0x5386)||(bank==3&&pc==0x6e85)||(bank==5&&pc==0x4d41)))return true;
        return value!=static_cast<unsigned char>(ram[address-0xc000]-1);
    }
};
